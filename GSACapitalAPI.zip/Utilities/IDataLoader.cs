﻿namespace Utilities
{
    public interface IDataLoader
    {
        string[] Load(string path);
    }
}