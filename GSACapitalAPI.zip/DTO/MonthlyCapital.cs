﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class MonthlyCapital
    {
        public string strategy { get; set; }
        public long capital { get; set; }
        public string date { get; set; }
    }
}
