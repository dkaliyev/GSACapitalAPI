﻿using System;

namespace DTO
{
    public class CapitalDTO
    {
        public string Name { get; set; }
        public long Value { get; set; }
        public DateTime Date { get; set; }
    }
}
